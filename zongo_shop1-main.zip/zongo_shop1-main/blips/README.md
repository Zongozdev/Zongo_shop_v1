# fxserver-esx_map
FXServer ESX Blips manager

[INSTALLATION]

1) CD in your resources/[esx] folder
2) Clone the repository
```
git clone https://github.com/ElNelyo/fxserver_esx_map.git esx_map
```

4) Add this in your server.cfg :

```
start esx_map
```
