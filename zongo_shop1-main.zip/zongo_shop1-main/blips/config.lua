Config = {}

Config.Map = {
  {name="Superrete", color=2, id=59, x=25.67 , y = -1346.37, z = 29.49},
  {name="Superrete", color=2, id=59, x = 2557.18,  y = 382.4,    z = 107.62},
  {name="Superrete", color=2, id=59, x = -3039.46, y = 585.99,   z = 6.91},
  {name="Superrete", color=2, id=59, x = -3242.34, y = 1001.7,   z = 11.83},
  {name="Superrete", color=2, id=59, x = 547.44,   y = 2671.2,   z = 41.16},
  {name="Superrete", color=2, id=59, x = 1961.43,  y = 3740.94,  z = 31.34},
  {name="Superrete", color=2, id=59, x = 2678.9,   y = 3280.68,  z = 54.24},
  {name="Superrete", color=2, id=59, x = 1729.34,  y = 6414.49,  z = 34.04},
  {name="Superrete", color=2, id=59, x = 25.95,    y = -1345.46, z = 28.5},
  {name="Superrete", color=2, id=59, x = 1136.14,  y = -982.3,   z = 45.42},
  {name="Superrete", color=2, id=59, x = -1223.19, y = -907.07,  z = 11.33},
  {name="Superrete", color=2, id=59, x = -1487.2,  y = -379.53,  z = 39.16},
  {name="Superrete", color=2, id=59, x = -2968.16, y = 390.43,   z = 14.04},
  {name="Superrete", color=2, id=59, x = 1166.02,  y = 2708.99,  z = 37.16},
  {name="Superrete", color=2, id=59, x = 1392.42,  y = 3604.59,  z = 33.98},
  {name="Superrete", color=2, id=59, x = -48.5,    y = -1757.58, z = 28.42},
  {name="Superrete", color=2, id=59, x = 1163.26,  y = -324.1,   z = 68.21},
  {name="Superrete", color=2, id=59, x = -707.67,  y = -914.72,  z = 18.22},
  {name="Superrete", color=2, id=59, x = -1820.71, y = 792.42,   z = 137.12},
  {name="Superrete", color=2, id=59, x = 1698.44,  y = 4924.65,  z = 41.06},
}