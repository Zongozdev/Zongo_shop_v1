description 'ESX map'

client_scripts {
	'config.lua',
	'client/main.lua'
}
